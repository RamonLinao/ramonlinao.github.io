IF EXISTS (SELECT * FROM sys.sql_logins WHERE name = 'project-access')
DROP LOGIN [project-access];
GO

CREATE LOGIN [project-access]
WITH PASSWORD = 'Secret555',
CHECK_POLICY = OFF;
GO

USE Project;
GO

IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'project-access')
DROP USER [project-access];
GO

CREATE USER [project-access] FOR LOGIN [project-access];
GO

GRANT SELECT ON HR.Employee TO [project-access];
GO

USE Project;
GO

SELECT * FROM sys.database_permissions
WHERE grantee_principal_id = USER_ID('project-access');

IF EXISTS (SELECT * FROM sys.sql_logins WHERE name = 'project-update')
DROP LOGIN [project-update];
GO

CREATE LOGIN [project-update]
WITH PASSWORD = 'Secret555',
CHECK_POLICY = OFF;
GO

USE Project;
GO

IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'project-update')
DROP USER [project-update];
GO

CREATE USER [project-update] FOR LOGIN [project-update];
GO

GRANT INSERT, UPDATE, DELETE ON HR.Employee TO [project-update];
GO

USE Project;
GO

SELECT * FROM sys.database_permissions
WHERE grantee_principal_id = USER_ID('project-update');

USE Project;
GO

CREATE TRIGGER PreventDropTables
ON DATABASE
FOR DROP_TABLE
AS
BEGIN
    PRINT 'Table deletion is not allowed!';
    ROLLBACK;
END;
GO

DROP TABLE HR.Employee;