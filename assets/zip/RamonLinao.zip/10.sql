USE master;
GO

-- Set database to EMERGENCY mode
ALTER DATABASE Project SET EMERGENCY;
GO

-- Set SINGLE USER mode
ALTER DATABASE Project SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

-- Run repair
DBCC CHECKDB (Project, REPAIR_ALLOW_DATA_LOSS);
GO

-- Return to normal mode
ALTER DATABASE Project SET MULTI_USER;
GO


USE master;
GO

ALTER DATABASE Project SET MULTI_USER;
GO