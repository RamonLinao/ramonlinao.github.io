USE master;
GO

ALTER DATABASE Project SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

RESTORE DATABASE Project
FROM DISK = 'C:\Project\Project.bak'
WITH REPLACE, RECOVERY;
GO

ALTER DATABASE Project SET MULTI_USER;
GO

USE master;
GO

SELECT name, state_desc 
FROM sys.databases 
WHERE name = 'Project';