&{ 
echo -----SERVER1_RSOP------
gpresult /r /z 

echo -----SERVER2_RSOP------
gpresult /s server2 /u administrator /r /z

echo -----SERVER1_NETWORK_CONFIG------
Get-NetIPConfiguration 

echo -----SERVER2_NETWORK_CONFIG------
gwmi -ComputerName server2 win32_networkadapterconfiguration

echo -----FUNCTIONAL_LEVELS------
Get-ADDomain | fl Name,DomainMode 
Get-ADForest | fl Name,ForestMode 

echo -----GLOBAL_CATALOGS------
Get-ADDomainController -Discover -Service "GlobalCatalog"
} >c:\project\file1.txt

&{
echo -----DHCP_SCOPES------
Get-DhcpServerv4Scope  

echo -----DHCP_RESERVATIONS------
Get-DhcpServerv4Scope | Get-DhcpServerv4Reservation 

echo -----DHCP_SERVER_OPTIONS------
Get-DhcpServerv4OptionValue 

echo -----DHCP_SCOPE_POLICIES------
Get-DhcpServerv4Policy -scopeid 192.168.255.0 

echo -----DHCP_FAILOVER------
Get-DhcpServerv4Failover 

echo -----DHCP_EXCLUSIONS------
Get-DhcpServerv4ExclusionRange 

echo -----DHCP_SERVER_DYNAMIC_UPDATE_SETTINGS------
Get-DhcpServerv4DnsSetting 

echo -----DHCP_SERVER_AUTHORIZED------
Get-DhcpServerSetting | fl IsAuthorized

echo -----WDS_BOOT_IMAGE------
Get-WdsBootImage 

echo -----WDS_INSTALL_IMAGE------
Get-WdsInstallImage 
} >c:\project\file2.txt

&{
echo -----WINS_REPLICATION------
netsh wins server show statistics 

echo -----WINS_RECORDS------
netsh wins server show database "server={}"
} >c:\project\file3.txt

&{
echo -----DNS_ZONES_SERVER1------
Get-DnsServerZone 

echo -----DNS_ZONES_SERVER2------
Get-DnsServerZone -computername server2
 
echo -----DNS_SCAVENGING------
Get-DnsServerScavenging 

echo -----DNS_GLOBALNAMES_ZONE------
Get-DnsServerGlobalNameZone
 
echo -----DNS_ALL_RESOURCE_RECORDS------
Get-DnsServerZone | Get-DnsServerResourceRecord 
} >c:\project\file4.txt

&{ 
echo -----REMOTE_ACCESS_CONFIG------
Get-RemoteAccess 

echo -----REMOTE_ACCESS_CONNECTION_DETAILS------
cat 'C:\Windows\System32\LogFiles\IN*'
} >c:\project\file5.txt

&{
echo -----DFS_ROOT------
Get-DfsnRoot 

echo -----DFS_TARGETS------
Get-DfsnFolderTarget \\ramonlinao.com\warehouse\share1
Get-DfsnFolderTarget \\ramonlinao.com\warehouse\share2
Get-DfsnFolderTarget \\ramonlinao.com\warehouse\share3

echo -----DFS_REPLICATION_GROUP------
Get-DfsReplicationGroup | Get-DfsReplicatedFolder 
} >c:\project\file6.txt

&{
echo -----ORG_UNITS------
Get-ADOrganizationalUnit -Filter * |ft distinguishedname,linkedgrouppolicyobjects

echo -----GROUPS_AND_GROUP_MEMBERSHIP------
$Groups = Get-ADGroup -Properties * -Filter * -SearchBase "DC=ramonlinao,DC=com" 
Foreach($G In $Groups)
{
    Write-Host $G.Name
    Write-Host "-------------"
    $G.Members
}
} >c:\project\file7.txt

&{
echo -----SHARED_PRINTERS------
Get-Printer -Full | where Shared -eq $true | fl

echo -----USERS------
Get-ADUser -Filter * | ft

echo -----COMPUTERS------
Get-ADComputer -Filter * | ft

echo -----ORG_UNITS_WITH_BLOCK_INHERITANCE------
Get-ADOrganizationalUnit -Filter * | ?{(Get-GPInheritance $_.DistinguishedName).GpoInheritanceBlocked -eq "Yes"} | ft DistinguishedName
} >c:\project\file8.txt

Get-GPOReport -Name "GPO-Mfg" -ReportType HTML -Path "c:\project\GPO-Mfg.html"

&{
echo -----TRUSTS------
Get-ADTrust -Filter *

echo -----SITES_AND_DCS------
$ReportFile = "C:\ADSiteInfo.CSV"
Remove-item $ReportFile -ErrorAction SilentlyContinue
$ThisString="AD Site,Location,Site Option,Current ISTG,Subnets,Servers,In Site Links,Bridgehead Servers"
Add-Content "$ReportFile" $ThisString

$CurForestName = "ramonlinao.com"
$a = new-object System.DirectoryServices.ActiveDirectory.DirectoryContext("Forest", $CurForestName)
[array]$ADSites=[System.DirectoryServices.ActiveDirectory.Forest]::GetForest($a).sites
$ADSites
ForEach ($Site in $ADSites)
{
    $SiteName = $Site.Name
    $SiteLocation = $site.Location
    $SiteOptions = $Site.Options
    $SiteISTG = $Site.InterSiteTopologyGenerator

    [array] $SiteServers = $Site.Servers.Count
    [array] $SiteSubnets = $Site.Subnets.Count
    [array] $SiteLinks = $Site.SiteLinks.Count
    [array] $SiteBH = $Site.BridgeheadServers.Count

    $FinalVal=$SiteName+","+'"'+$SiteLocation+'"'+","+'"'+$SiteOptions+'"'+","+$SiteISTG+","+$SiteSubnets+","+$SiteServers+","+$SiteLinks+","+$SiteBH
    Add-Content "$ReportFile" $FinalVal          
}

echo -----SITE_LINKS------
Get-ADReplicationSiteLink -filter * |fl
} >c:\project\file9.txt

&{
echo -----iSCSI_CONFIGURATION------
$session=New-PSSession -ComputerName server2
Invoke-Command -Command {Get-IscsiTarget} -session $session
Invoke-Command -Command {Get-Volume -Driveletter X} -session $session

echo -----DEDUP_STATUS------
Invoke-Command -Command {Get-Dedupstatus} -session $session
} >c:\project\file10.txt

&{
echo -----WSUS_SYNCHRONIZATION------
$wsusSync = (Get-WsusServer).GetSubscription().GetSynchronizationHistory()
$wsusSync  

echo -----WSUS_AUTO_SYNCHRONIZATION------
$autoSync = (Get-WsusServer).GetSubscription().SynchronizeAutomatically
$autoSync
} >c:\project\file11.txt
